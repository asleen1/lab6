package exercise1;

public class Account {
    private double accountBalance;

    public Account(double initialBalance) {
        if (initialBalance > 0.0) {
            accountBalance = initialBalance;
        }
    }

    public synchronized void deposit(double amount) {
        if (amount > 0.0) {
            accountBalance += amount;
            System.out.printf("Deposited: %.2f, New Balance: %.2f%n", amount, accountBalance);
        }
    }

    public synchronized void withdraw(double amount) {
        if (amount > 0.0 && accountBalance >= amount) {
            accountBalance -= amount;
            System.out.printf("Withdrew: %.2f, New Balance: %.2f%n", amount, accountBalance);
        } else {
            System.out.printf("Insufficient funds for withdrawal of: %.2f%n", amount);
        }
    }

    public double getAccountBalance() {
        return accountBalance;
    }
}
