package exercise1;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AccountTest {
    public static void main(String[] args) {
        Account sharedAccount = new Account(1000.0);

        ArrayList<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(sharedAccount, true, 200.0)); // Deposit
        transactions.add(new Transaction(sharedAccount, false, 300.0)); // Withdraw
        transactions.add(new Transaction(sharedAccount, true, 150.0)); // Deposit
        transactions.add(new Transaction(sharedAccount, false, 400.0)); // Withdraw

        ExecutorService executor = Executors.newFixedThreadPool(2);

        System.out.printf("Initial Balance: %.2f%n", sharedAccount.getAccountBalance());
        for (Transaction transaction : transactions) {
            executor.execute(transaction);
        }
        executor.shutdown();

        while (!executor.isTerminated()) {
            // Wait for all threads to finish
        }
        System.out.printf("Final Balance: %.2f%n", sharedAccount.getAccountBalance());
    }
}
