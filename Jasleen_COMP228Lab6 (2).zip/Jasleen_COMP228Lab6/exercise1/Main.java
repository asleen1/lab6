package exercise1;

public class Main {
    public static void main(String[] args) {
        
        AccountTest.main(args);  
    }
}
